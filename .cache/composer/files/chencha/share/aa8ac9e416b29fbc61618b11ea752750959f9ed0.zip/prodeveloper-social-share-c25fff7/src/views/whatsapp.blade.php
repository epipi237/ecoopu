whatsapp://send?text={{ rawurlencode("$title $url") }}
