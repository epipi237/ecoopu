<ul>
    @foreach(Share::services() as $service)
    @endforeach
</ul>
