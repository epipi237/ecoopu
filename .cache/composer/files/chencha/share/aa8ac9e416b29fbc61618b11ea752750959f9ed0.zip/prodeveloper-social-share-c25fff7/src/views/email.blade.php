mailto:?subject={{ rawurlencode($title) }}&body={{ rawurlencode($url) }}
