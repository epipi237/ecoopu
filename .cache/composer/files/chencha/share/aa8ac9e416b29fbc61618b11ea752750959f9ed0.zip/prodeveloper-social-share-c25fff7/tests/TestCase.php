<?php

class TestCase extends Orchestra\Testbench\TestCase
{
}
